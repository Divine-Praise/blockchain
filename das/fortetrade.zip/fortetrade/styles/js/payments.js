$('a.typepm48').each(function () {
    var href = $(this).attr('href');
    $(this).attr('href', 'http://blockchain.info/tx/' + href );
});


$('a.typepm69').each(function () {
    var href = $(this).attr('href');
    $(this).attr('href', 'https://etherscan.io/tx/' + href );
});


$('a.typepm79').each(function () {
    var href = $(this).attr('href');
    $(this).attr('href', 'https://dogechain.info/tx/' + href );
});

$('a.typepm68').each(function () {
    var href = $(this).attr('href');
    $(this).attr('href', 'https://live.blockcypher.com/ltc/tx/' + href );
});


$('a.typepm77').each(function () {
    var href = $(this).attr('href');
    $(this).attr('href', 'https://www.blockchain.com/bch/tx/' + href );
});

$('a.typepm71').each(function () {
    var href = $(this).attr('href');
    $(this).attr('href', 'https://explorer.dash.org/tx/' + href );
});